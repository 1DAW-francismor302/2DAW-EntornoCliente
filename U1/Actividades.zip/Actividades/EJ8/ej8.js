"use strict"
{
    let n = parseInt(prompt("Introduce un número: "));

    for (let i = 0; i < 10; i++) {
        console.log(n * (i+1))
    }
}