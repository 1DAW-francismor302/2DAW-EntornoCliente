"use strict"

{
    function contarNumeroCaracter (texto) {
        console.log(texto.length);
    }

    contarNumeroCaracter("Hola Mundo");
}