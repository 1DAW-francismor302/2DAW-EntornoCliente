"use strict"
{
    function repetirTexto (texto, cantidad){
        console.log(texto.repeat(cantidad));
    }

    repetirTexto("Hola Mundo ", 2);
}