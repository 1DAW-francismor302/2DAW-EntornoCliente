"use strict"

{
    /**
     * Un DNI es válido cuando tiene 9 caracteres, de esos 9 caracteres 8 son números y el último caracter es una letra escrita en mayúsculas.
     */

}