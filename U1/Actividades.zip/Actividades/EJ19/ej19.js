"use strict"

{
    function textosSeparados(texto, caracter){
        console.log(texto.split(caracter));
    }

    textosSeparados("hola que tal", ' ');
}