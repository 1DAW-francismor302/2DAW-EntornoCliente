"use strict"

{
    function recortatexto (texto, indice){
        console.log(texto.substring(0, indice));
    }
    
    recortatexto("Hola Mundo", 4);
}